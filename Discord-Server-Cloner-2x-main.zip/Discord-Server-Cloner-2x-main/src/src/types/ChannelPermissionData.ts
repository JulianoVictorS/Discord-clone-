export interface ChannelPermissionsData {
    roleName: string;
    allow: string;
    deny: string;
}
